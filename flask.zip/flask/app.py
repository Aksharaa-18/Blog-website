from flask import Flask, render_template

app = Flask(__name__)

# Sample blog posts with titles, dates, and content related to Sentiment Analysis
posts = [
    {
        'title': 'What is Sentiment Analysis?',
        'date': 'April 20, 2025',
        'content': 'Sentiment Analysis, also known as opinion mining, is a field of study that analyzes people’s opinions, sentiments, evaluations, attitudes, and emotions from written language. It plays an essential role in natural language processing (NLP) and is used extensively in social media monitoring and customer feedback analysis.'
    },
    {
        'title': 'Why is Sentiment Analysis Important?',
        'date': 'April 22, 2025',
        'content': 'Sentiment Analysis is vital for understanding consumer opinions and feedback. Businesses use it to track public sentiment towards products and services in real-time, helping them improve their offerings. It can also be used to understand political opinions or social trends.'
    },
    {
        'title': 'Challenges in Sentiment Analysis',
        'date': 'April 24, 2025',
        'content': 'Despite its usefulness, Sentiment Analysis faces challenges such as sarcasm detection, the complexity of emotions, and context understanding. Many models still struggle to interpret informal language, making it difficult to achieve high accuracy in sentiment classification.'
    },
    {
        'title': 'Sentiment Analysis Using Machine Learning',
        'date': 'April 26, 2025',
        'content': 'Machine Learning models such as Naive Bayes, Support Vector Machines (SVM), and Long Short-Term Memory (LSTM) networks are commonly used for Sentiment Analysis. These models are trained on vast amounts of data to detect patterns in text and classify the sentiment as positive, negative, or neutral.'
    }
]

@app.route('/')
def home():
    # Renders the homepage and passes the posts to the template
    return render_template('home.html', posts=posts)

@app.route('/post/<int:post_id>')
def post(post_id):
    # Renders the individual post page using the post ID
    return render_template('post.html', post=posts[post_id])

if __name__ == '__main__':
    app.run(debug=True)
